#!/bin/sh

qemu-system-x86_64 \
    -kernel ./bzImage \
    -initrd ./initramfs.cpio.gz \
    -append "console=ttyS0 loglevel=0 oops=panic nopti" \
    -cpu kvm64,+smep,+smap -enable-kvm \
    -smp 2 \
    -m 256 \
    -no-reboot -nographic -monitor none

