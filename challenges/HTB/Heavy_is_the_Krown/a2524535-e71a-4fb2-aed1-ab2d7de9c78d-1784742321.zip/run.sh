#!/bin/sh
qemu-system-x86_64 \
      -nodefaults \
      -display none \
      -serial stdio \
      -cpu qemu64,+smep,+smap \
      -kernel ./vmlinuz \
      -initrd ./initramfs.cpio.gz \
      -append 'console=ttyS0 quiet loglevel=3 oops=panic panic=1 init=/init root=/dev/ram0' \
      -nographic \
      -no-reboot \
      -smp 2 \
      -m 256M
